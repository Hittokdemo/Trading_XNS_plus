package com.evanemran.xns_plus.Interface

import com.evanemran.xns_plus.Model.LoginResponse
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface LoginApiService {
    @FormUrlEncoded
    @POST("login")
    suspend fun loginApi(
        @Field("email") email: String,
        @Field("password") password: String
    ): Response<LoginResponse>

}