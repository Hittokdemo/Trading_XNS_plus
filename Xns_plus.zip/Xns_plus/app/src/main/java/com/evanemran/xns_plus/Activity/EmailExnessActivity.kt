package com.evanemran.xns_plus.Activity

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.evanemran.xns_plus.databinding.ActivityEmailExnessBinding

class EmailExnessActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEmailExnessBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        binding = ActivityEmailExnessBinding.inflate(layoutInflater)
        setContentView(binding.root)


        sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)

        binding.signInButton.setOnClickListener {
            if (isValidEmail(binding.email.text.toString().trim())) {
                // Email is valid
                val intent = Intent(this,ChoosePasswordActivity::class.java).apply {
                    putExtra("userEmail",binding.email.text.toString())
                }
                startActivity(intent)
            } else {
                // Email is invalid
                Toast.makeText(this, "Invalid Email", Toast.LENGTH_SHORT).show()
            }
        }

        binding.backBtn.setOnClickListener {
            finish()
        }

    }
    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    @Deprecated("This method has been deprecated in favor of using the\n   " +
            "   {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n   " +
            "   The OnBackPressedDispatcher controls how back button events are dispatched\n  " +
            "    to one or more {@link OnBackPressedCallback} objects.")
    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}