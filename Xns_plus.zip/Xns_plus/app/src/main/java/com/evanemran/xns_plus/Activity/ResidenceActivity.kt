package com.evanemran.xns_plus.Activity

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.evanemran.xns_plus.databinding.ActivityResidenceBinding
import com.hbb20.CountryCodePicker





class ResidenceActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResidenceBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        binding = ActivityResidenceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)
        val checkBox = binding.checkbox.isChecked
        if (checkBox) {
            binding.continueButton.setOnClickListener {
                val intent = Intent(this, EmailExnessActivity::class.java).apply {
                    putExtra("NumberCode", binding.countryCode.selectedCountryCode)
                }
                startActivity(intent)
            }
        } else {
            Toast.makeText(this, "Please select 'I declare and confirm'", Toast.LENGTH_SHORT).show()
        }

        binding.backBtn.setOnClickListener {
            finish()
        }


    }

    @Deprecated("This method has been deprecated in favor of using the\n    " +
            "  {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n   " +
            "   The OnBackPressedDispatcher controls how back button events are dispatched\n   " +
            "   to one or more {@link OnBackPressedCallback} objects.")
    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}