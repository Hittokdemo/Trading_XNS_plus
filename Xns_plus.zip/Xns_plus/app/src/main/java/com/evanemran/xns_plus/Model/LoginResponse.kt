package com.evanemran.xns_plus.Model

data class LoginResponse(
    val status: String?=null,
    val message: String?=null,
    val user_id: String?=null
)

