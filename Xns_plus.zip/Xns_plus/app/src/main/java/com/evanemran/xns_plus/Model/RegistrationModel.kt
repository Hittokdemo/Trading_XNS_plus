package com.evanemran.xns_plus.Model

data class RegistrationModel(val email:String?=null,val mobile:String?=null,val password:String?=null,val pass_code:String?=null)
