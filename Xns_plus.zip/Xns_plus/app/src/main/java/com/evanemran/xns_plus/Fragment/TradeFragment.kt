package com.evanemran.xns_plus.Fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evanemran.xns_plus.Activity.PriceAlertsActivity
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.AccountBottomSheetBinding
import com.evanemran.xns_plus.databinding.FragmentAccountBinding
import com.evanemran.xns_plus.databinding.FragmentTradeBinding
import com.google.android.material.bottomsheet.BottomSheetDialog


class TradeFragment : Fragment() {
    private var _binding: FragmentTradeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View
    {
        // Inflate the layout for this fragment
        _binding = FragmentTradeBinding.inflate(inflater, container, false)
        _binding!!.accountDel.setOnClickListener {
            val binding = AccountBottomSheetBinding.inflate(inflater, container, false)
            val bottomSheet = BottomSheetDialog(requireActivity())
            bottomSheet.setContentView(binding.root)
            bottomSheet.create()
            bottomSheet.show()
        }
        binding.prizeAlertBtn.setOnClickListener {
            startActivity(Intent(requireActivity(),PriceAlertsActivity::class.java))
        }

        return binding.root
    }

    private fun openAccountBottom() {
        TODO("Not yet implemented")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Clear the binding reference to avoid memory leaks
        _binding = null
    }

}