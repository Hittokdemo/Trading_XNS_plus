package com.evanemran.xns_plus.Activity

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.ActivityNotificationBinding

class NotificationActivity : AppCompatActivity() {
    lateinit var binding: ActivityNotificationBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.closeBtn.setOnClickListener {
            finish()
        }

    }

    @Deprecated("This method has been deprecated in favor of using the\n  " +
            "    {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n   " +
            "   The OnBackPressedDispatcher controls how back button events are dispatched\n   " +
            "   to one or more {@link OnBackPressedCallback} objects.")
    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}