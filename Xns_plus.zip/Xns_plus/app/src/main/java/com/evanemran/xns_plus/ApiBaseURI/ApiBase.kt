package com.evanemran.xns_plus.ApiBaseURI

object ApiBase {
    const val baseUri = "http://45.79.127.105/xnsplus/api/"
}