package com.evanemran.xns_plus.Activity

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.ActivityPriceAlertsBinding

class PriceAlertsActivity : AppCompatActivity() {
    lateinit var binding: ActivityPriceAlertsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPriceAlertsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backButton.setOnClickListener {
            finish()
        }

    }

    @Deprecated("This method has been deprecated in favor of using the\n  " +
            "    {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n    " +
            "  The OnBackPressedDispatcher controls how back button events are dispatched\n  " +
            "    to one or more {@link OnBackPressedCallback} objects.")
    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}