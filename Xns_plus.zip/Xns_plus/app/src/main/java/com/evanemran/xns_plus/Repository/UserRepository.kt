package com.evanemran.xns_plus.Repository

import android.util.Log
import com.evanemran.xns_plus.Interface.GetProfileApiService
import com.evanemran.xns_plus.Interface.LoginApiService
import com.evanemran.xns_plus.Interface.RegistrationApiService
import com.evanemran.xns_plus.Interface.UserProfileUpdateApiService
import com.evanemran.xns_plus.Model.GetProfileModel
import com.evanemran.xns_plus.Model.LoginModel
import com.evanemran.xns_plus.Model.LoginResponse
import com.evanemran.xns_plus.Model.RegistrationModel
import com.evanemran.xns_plus.Model.UserResponse
import com.evanemran.xns_plus.Model.UserUpdateParams
import com.evanemran.xns_plus.Retrofit_client.RetrofitClient
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Response
import java.io.File
import java.io.FileInputStream

class UserRepository {
    private val registrationApiService =
        RetrofitClient.retrofit.create(RegistrationApiService::class.java)
    private val loginApiService = RetrofitClient.retrofit.create(LoginApiService::class.java)
    private val getUserProfileApiService =
        RetrofitClient.retrofit.create(GetProfileApiService::class.java)
    private val userProfileUpdateApiService =
        RetrofitClient.retrofit.create(UserProfileUpdateApiService::class.java)

    suspend fun registrationFetch(registrationModel: RegistrationModel): Response<UserResponse>? {
        return try {
            // Ensure all required fields are non-null
            if (registrationModel.email != null && registrationModel.mobile != null &&
                registrationModel.password != null && registrationModel.pass_code != null
            ) {

                // Make the API call
                registrationApiService.createUser(
                    email = registrationModel.email,
                    mobile = registrationModel.mobile,
                    password = registrationModel.password,
                    pass_code = registrationModel.pass_code
                )
            } else {
                Log.e("UserRepository", "Missing required fields in registrationModel")
                null
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error during registration: ${e.message}")
            null // Return null in case of an exception
        }
    }

    suspend fun userProfileUpdate(userUpdateParams: UserUpdateParams): Response<UserResponse>? {
        return try {
            // Validate non-null fields
            requireNotNull(userUpdateParams.user_id) { "User ID cannot be null" }
            requireNotNull(userUpdateParams.email) { "Email cannot be null" }
            requireNotNull(userUpdateParams.name) { "Name cannot be null" }
            requireNotNull(userUpdateParams.mobile) { "Mobile cannot be null" }
            requireNotNull(userUpdateParams.password) { "Password cannot be null" }
            requireNotNull(userUpdateParams.pass_code) { "Pass code cannot be null" }
            requireNotNull(userUpdateParams.image) { "Image cannot be null" }

            // Convert image file to byte array and MultipartBody.Part
            val byteArray = fileToByteArray(userUpdateParams.image)
            val imagePart = byteArrayToMultipartBody(byteArray, "image", userUpdateParams.image.name)

            // Make the API call
            userProfileUpdateApiService.userProfileUpdate(
                user_id = userUpdateParams.user_id.toRequestBody("text/plain".toMediaTypeOrNull()),
                email = userUpdateParams.email.toRequestBody("text/plain".toMediaTypeOrNull()),
                name = userUpdateParams.name.toRequestBody("text/plain".toMediaTypeOrNull()),
                mobile = userUpdateParams.mobile.toRequestBody("text/plain".toMediaTypeOrNull()),
                password = userUpdateParams.password.toRequestBody("text/plain".toMediaTypeOrNull()),
                pass_code = userUpdateParams.pass_code.toRequestBody("text/plain".toMediaTypeOrNull()),
                image = imagePart
            )
        } catch (e: Exception) {
            Log.e("UserRepository", "Error during profile update: ${e.message}")
            null
        }
    }

    // Helper functions (Ensure these functions exist and work as expected)
    private fun fileToByteArray(file: File): ByteArray {
        return file.readBytes()
    }

    private fun byteArrayToMultipartBody(byteArray: ByteArray, partName: String, fileName: String): MultipartBody.Part {
        val requestBody = byteArray.toRequestBody("image/*".toMediaTypeOrNull())
        return MultipartBody.Part.createFormData(partName, fileName, requestBody)
    }


    suspend fun loginFetch(loginModel: LoginModel): Response<LoginResponse>? {
        return try {
            // Ensure all required fields are non-null
            if (loginModel.email != null && loginModel.password != null) {
                // Make the API call
                loginApiService.loginApi(
                    email = loginModel.email,
                    password = loginModel.password
                )
            } else {
                Log.e("UserRepository", "Missing required fields in registrationModel")
                null
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error during registration: ${e.message}")
            null // Return null in case of an exception
        }
    }

    suspend fun profileFetch(userId: String): Response<GetProfileModel>? {
        return try {
            // Ensure all required fields are non-null
            getUserProfileApiService.getUserProfile(
                user_id = userId
            )
        } catch (e: Exception) {
            Log.e("UserRepository", "Error during registration: ${e.message}")
            null // Return null in case of an exception
        }
    }


    // Helper function to convert ByteArray to MultipartBody.Part
    private fun byteArrayToMultipartBody(
        byteArray: ByteArray,
        partName: String = "image"
    ): MultipartBody.Part {
        val requestBody = RequestBody.create("image/png".toMediaTypeOrNull(), byteArray)
        return MultipartBody.Part.createFormData(partName, "profile_image.png", requestBody)
    }


}
