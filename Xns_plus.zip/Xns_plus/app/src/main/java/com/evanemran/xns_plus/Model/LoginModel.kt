package com.evanemran.xns_plus.Model

data class LoginModel(val email:String?=null,val password:String?=null)
