package com.evanemran.xns_plus.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.AccountBottomSheetBinding
import com.evanemran.xns_plus.databinding.FragmentMarketsBinding
import com.evanemran.xns_plus.databinding.FragmentTradeBinding
import com.google.android.material.bottomsheet.BottomSheetDialog

class MarketsFragment : Fragment() {

    private var _binding: FragmentMarketsBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View
    {
        // Inflate the layout for this fragment
        _binding = FragmentMarketsBinding.inflate(inflater, container, false)
        _binding!!.accountDel.setOnClickListener {
            val binding = AccountBottomSheetBinding.inflate(inflater, container, false)
            val bottomSheet = BottomSheetDialog(requireActivity())
            bottomSheet.setContentView(binding.root)
            bottomSheet.create()
            bottomSheet.show()
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Clear the binding reference to avoid memory leaks
        _binding = null
    }


}