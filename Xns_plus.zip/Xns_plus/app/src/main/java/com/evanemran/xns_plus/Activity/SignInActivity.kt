package com.evanemran.xns_plus.Activity

import android.app.ProgressDialog
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.InputType
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.evanemran.xns_plus.MVVM.UserViewModel
import com.evanemran.xns_plus.Model.LoginModel
import com.evanemran.xns_plus.ProgressDialog.showProgressDialog
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.ActivitySignInBinding

class SignInActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignInBinding
    private lateinit var sharedPreferences:SharedPreferences
    private lateinit var progressDialog: ProgressDialog
    private lateinit var userViewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userViewModel = ViewModelProvider(this)[UserViewModel::class.java]
        sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)

        binding.passwordEye.setOnClickListener {
            // Check the current input type
            if (binding.password.inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                // Set to hidden
                binding.password.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                binding.passwordEye.setImageResource(R.drawable.eye_icon) // Set your show icon here
            } else {
                // Set to visible
                binding.password.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                binding.passwordEye.setImageResource(R.drawable.hide_icon) // Set your hide icon here
            }

            // Move the cursor to the end of the text
            binding.password.setSelection(binding.password.text.length)
        }


        binding.signInButton.setOnClickListener {
            val userEmail = binding.emailEdit.text.toString() // Assuming you have an EditText for email input
            if (isValidEmail(userEmail)) {
              loginApi()
            } else {
                Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
            }
        }
        binding.backBtn.setOnClickListener {
          finish()
        }

        userViewModel.loginResponse.observe(this) { response ->
            progressDialog.dismiss()
            if (response?.status == "success") {
                val edits = sharedPreferences.edit()
                edits.putString("userID", response.user_id)
                edits.apply()
                startActivity(Intent(this, PasswordSecurelyActivity::class.java))
                Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()

            } else {
                Toast.makeText(this, response?.message ?: "Registration failed", Toast.LENGTH_SHORT)
                    .show()
            }
        }

        userViewModel.error.observe(this) { errorMessage ->
            progressDialog.dismiss()
            errorMessage?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            }
        }

    }
    // Function to check if the email is valid
    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun loginApi() {
        // Check if the password field is empty
        if (binding.password.text.isEmpty()) {
            binding.password.error = "Please enter a password"
            return
        }

        // Show progress dialog and proceed with login
        progressDialog = showProgressDialog(this, "Please wait...")
        val loginModel = LoginModel(
            email = binding.emailEdit.text.toString().trim(),
            password = binding.password.text.toString().trim()
        )
        userViewModel.fetchLoginResponse(loginModel)
    }

    @Deprecated("This method has been deprecated in favor of using the\n   " +
            "   {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n   " +
            "   The OnBackPressedDispatcher controls how back button events are dispatched\n  " +
            "    to one or more {@link OnBackPressedCallback} objects.")
    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}