package com.evanemran.xns_plus.MVVM

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.evanemran.xns_plus.Model.GetProfileModel
import com.evanemran.xns_plus.Model.LoginModel
import com.evanemran.xns_plus.Model.LoginResponse
import com.evanemran.xns_plus.Model.RegistrationModel
import com.evanemran.xns_plus.Model.UserResponse
import com.evanemran.xns_plus.Model.UserUpdateParams
import com.evanemran.xns_plus.Repository.UserRepository
import kotlinx.coroutines.launch

class UserViewModel : ViewModel() {
    private val repository = UserRepository()

    private val _userResponse = MutableLiveData<UserResponse>()
    val userResponse: LiveData<UserResponse> get() = _userResponse

    private val _loginResponse = MutableLiveData<LoginResponse>()
    val loginResponse: LiveData<LoginResponse> get() = _loginResponse

    private val _getProfile = MutableLiveData<GetProfileModel>()
    val getProfile: LiveData<GetProfileModel> get() = _getProfile

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> get() = _error

    fun fetchRegistration(registrationModel: RegistrationModel){
        viewModelScope.launch {
            try {
                val response = repository.registrationFetch(registrationModel)
                if (response != null) {
                    if (response.isSuccessful) {
                        _userResponse.postValue(response.body())
                    } else {
                        _error.postValue("Error: ${response.code()}")
                    }
                }
            }catch (e:Exception){
                Log.e("UserViewModel",e.message.toString())
                _error.postValue("Exception: ${e.message}")
            }
        }
    }

    fun fetchLoginResponse(loginModel: LoginModel)
    {
        viewModelScope.launch {
            try {
                val response = repository.loginFetch(loginModel)
                if (response != null) {
                    if (response.isSuccessful) {
                        _loginResponse.postValue(response.body())
                    } else {
                        _error.postValue("Error: ${response.code()}")
                    }
                }
            }catch (e:Exception){
                Log.e("UserViewModel",e.message.toString())
                _error.postValue("Exception: ${e.message}")
            }
        }
    }

     fun getProfileUser(userId:String){
         viewModelScope.launch {
             try {

                 val response = repository.profileFetch(userId)
                 if (response != null) {
                     if (response.isSuccessful) {
                         _getProfile.postValue(response.body())
                     } else {
                         _error.postValue("Error: ${response.code()}")
                     }
                 }
             }catch (e:Exception){
                 Log.e("UserViewModel",e.message.toString())
                 _error.postValue("Exception: ${e.message}")
             }
         }

    }

    fun userProfileUpdate(userUpdateParams: UserUpdateParams){
        viewModelScope.launch {
            try {
                val response = repository.userProfileUpdate(userUpdateParams)
                if (response != null) {
                    if (response.isSuccessful) {
                        _userResponse.postValue(response.body())
                    } else {
                        _error.postValue("Error: ${response.code()}")
                    }
                }
            }catch (e:Exception){
                Log.e("UserViewModel",e.message.toString())
                _error.postValue("Exception: ${e.message}")
            }
        }
    }

}