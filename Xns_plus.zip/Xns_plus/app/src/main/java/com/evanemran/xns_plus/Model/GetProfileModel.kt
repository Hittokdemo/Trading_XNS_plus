package com.evanemran.xns_plus.Model

data class GetProfileModel(
    val id: String?=null,
    val name: String?=null,
    val email: String?=null,
    val mobile: String?=null,
    val password: String?=null,
    val pass_code: String?=null,
    val image: String?=null
)
