package com.evanemran.xns_plus.Fragment

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.evanemran.xns_plus.Activity.PasswordSecurelyActivity
import com.evanemran.xns_plus.Activity.ProfileUpdateActivity
import com.evanemran.xns_plus.MVVM.UserViewModel
import com.evanemran.xns_plus.Model.LoginModel
import com.evanemran.xns_plus.ProgressDialog.showProgressDialog
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.FragmentAccountBinding
import com.evanemran.xns_plus.databinding.FragmentProfileBinding


class ProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var progressDialog: ProgressDialog
    private lateinit var userViewModel: UserViewModel
    private var userId = ""
    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentProfileBinding.inflate(inflater, container, false)
        userViewModel = ViewModelProvider(this)[UserViewModel::class.java]
        sharedPreferences = requireActivity().getSharedPreferences("ActivityCheck", MODE_PRIVATE)
        userId = sharedPreferences.getString("userID","").toString()

        fetchUserProfile()

        userViewModel.getProfile.observe(requireActivity(), Observer { response ->
            progressDialog.dismiss()
            if (response!=null){
                val profileImage = "http://45.79.127.105/xnsplus/uploads/profile/"+response.image
                if (response.name != null){
                    binding.profileName.text = response.name
                }else{
                    binding.profileName.text = "user name not empty please Profile Update"
                }
                Glide.with(requireActivity()).load(profileImage).placeholder(R.drawable.ic_launcher_background).into(binding.profileIcon)
            }

        })

        userViewModel.error.observe(requireActivity(), Observer { errorMessage ->
            progressDialog.dismiss()
            errorMessage?.let {
                Toast.makeText(requireActivity(), it, Toast.LENGTH_SHORT).show()
            }
        })

        binding.updateBtn.setOnClickListener {
            startActivity(Intent(requireActivity(),ProfileUpdateActivity::class.java))
            requireActivity().finish()
        }


        return binding.root
    }

    private fun fetchUserProfile(){
        try {
            progressDialog = showProgressDialog(requireActivity(), "Please wait...")
            userViewModel.getProfileUser(userId)
        }catch (e:Exception){
            progressDialog.dismiss()
        }
    }


}