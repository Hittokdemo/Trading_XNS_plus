package com.evanemran.xns_plus.Activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.evanemran.xns_plus.databinding.ActivityRegisterSignInBinding

class RegisterSignInActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterSignInBinding
    private lateinit var sharedPreferences:SharedPreferences

    @SuppressLint("CommitPrefEdits")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        binding = ActivityRegisterSignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)

        binding.registerButton.setOnClickListener {
            startActivity(Intent(this,ResidenceActivity::class.java))
        }

        binding.signInButton.setOnClickListener {
            startActivity(Intent(this,SignInActivity::class.java))
        }



    }

}