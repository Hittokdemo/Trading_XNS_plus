package com.evanemran.xns_plus.ProgressDialog

import android.app.ProgressDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.evanemran.xns_plus.R

fun showProgressDialog(context: Context, message: String): ProgressDialog {
    val progressDialog = android.app.ProgressDialog(context)
    progressDialog.setMessage(message)
    progressDialog.setCancelable(false)

    // Set the background color based on the theme
    val backgroundColor = if (context.resources.configuration.uiMode and
        android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
        Color.BLACK // Dark background for dark mode
    } else {
        Color.WHITE // Light background for light mode
    }
    progressDialog.window?.setBackgroundDrawable(ColorDrawable(backgroundColor))

    // Set text color based on theme
    val textColor = ContextCompat.getColor(context, R.color.grey) // Use theme-compatible color resource
    progressDialog.setOnShowListener {
        val textView = progressDialog.findViewById<TextView>(android.R.id.message)
        textView?.setTextColor(textColor)
    }

    // Customize the progress bar color based on theme
    progressDialog.setOnShowListener {
        val progressBar = progressDialog.findViewById<ProgressBar>(android.R.id.progress)
        progressBar?.indeterminateDrawable?.setColorFilter(
            textColor,
            android.graphics.PorterDuff.Mode.SRC_IN
        )
    }

    progressDialog.show()
    return progressDialog
}
