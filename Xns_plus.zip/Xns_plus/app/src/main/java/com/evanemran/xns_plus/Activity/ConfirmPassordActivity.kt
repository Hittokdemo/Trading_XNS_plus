package com.evanemran.xns_plus.Activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.ActivityConfirmPassordBinding
import com.ozcanalasalvar.otp_view.view.OtpView

class ConfirmPassordActivity : AppCompatActivity() {
    lateinit var binding: ActivityConfirmPassordBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConfirmPassordBinding.inflate(layoutInflater)
        setContentView(binding.root)


        sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)
        val storedConfirmPassword = sharedPreferences.getString("confirmPassword", "")

        binding.passwordInput.apply {
            setAutoFocusEnabled(false)
            setErrorEnabled(false)
            setTextChangeListener(object : OtpView.ChangeListener {
                @SuppressLint("CommitPrefEdits")
                override fun onTextChange(value: String, completed: Boolean) {
                    if (storedConfirmPassword == value){
                        val edits = sharedPreferences.edit()
                        edits.putBoolean("SignIn",true)
                        edits.apply()
                        val intent = Intent(this@ConfirmPassordActivity,HomeActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }
            })
        }

        binding.backButton.setOnClickListener {
            finish()
        }

    }
}