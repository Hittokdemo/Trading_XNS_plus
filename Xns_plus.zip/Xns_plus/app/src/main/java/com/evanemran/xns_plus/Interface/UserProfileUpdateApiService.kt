package com.evanemran.xns_plus.Interface

import com.evanemran.xns_plus.Model.UserResponse
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import java.io.File

interface UserProfileUpdateApiService {
    @Multipart
    @POST("user_update")
    suspend fun userProfileUpdate(
        @Part("user_id") user_id: RequestBody,
        @Part("email") email: RequestBody,
        @Part("name") name: RequestBody,
        @Part("mobile") mobile: RequestBody,
        @Part("password") password: RequestBody,
        @Part("pass_code") pass_code: RequestBody,
        @Part image: MultipartBody.Part // Keep MultipartBody.Part only for the image
    ): Response<UserResponse>
}

// Function to prepare parameters for user profile update
fun prepareUserProfileUpdate(
    userId: String,
    email: String,
    name: String,
    mobile: String,
    password: String,
    passCode: String,
    imageFile: File
): Pair<Map<String, RequestBody>, MultipartBody.Part> {
    // Convert text fields to RequestBody
    val userIdBody = userId.toRequestBody("text/plain".toMediaTypeOrNull())
    val emailBody = email.toRequestBody("text/plain".toMediaTypeOrNull())
    val nameBody = name.toRequestBody("text/plain".toMediaTypeOrNull())
    val mobileBody = mobile.toRequestBody("text/plain".toMediaTypeOrNull())
    val passwordBody = password.toRequestBody("text/plain".toMediaTypeOrNull())
    val passCodeBody = passCode.toRequestBody("text/plain".toMediaTypeOrNull())

    // Convert image file to MultipartBody.Part
    val imageBody = MultipartBody.Part.createFormData(
        "image", imageFile.name, imageFile.asRequestBody("image/*".toMediaTypeOrNull())
    )

    // Create a map for the text fields
    val textFieldsMap = mapOf(
        "user_id" to userIdBody,
        "email" to emailBody,
        "name" to nameBody,
        "mobile" to mobileBody,
        "password" to passwordBody,
        "pass_code" to passCodeBody
    )

    return Pair(textFieldsMap, imageBody)
}
