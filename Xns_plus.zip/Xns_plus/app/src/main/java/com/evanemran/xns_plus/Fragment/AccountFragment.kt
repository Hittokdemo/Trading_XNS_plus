package com.evanemran.xns_plus.Fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.evanemran.xns_plus.Activity.NotificationActivity
import com.evanemran.xns_plus.Activity.PriceAlertsActivity
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.AccountBottomSheetBinding
import com.evanemran.xns_plus.databinding.FragmentAccountBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.tabs.TabLayout

class AccountFragment : Fragment() {
    private lateinit var binding: FragmentAccountBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout using View Binding
        binding = FragmentAccountBinding.inflate(inflater, container, false)
        binding.toolbar.setOnMenuItemClickListener { item -> // Handle menu item click
            when (item.itemId) {
                R.id.ringing -> {
                    // Handle the sort menu item click
                    startActivity(Intent(requireActivity(),NotificationActivity::class.java))
                    true
                }
                R.id.alarm -> {
                    // Handle the filter menu item click
                    startActivity(Intent(requireActivity(),PriceAlertsActivity::class.java))
                    true
                }
                else -> false
            }
        }

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Setup tab visibility based on the initially selected tab
        updateMenuBarVisibility(binding.tabLayout.selectedTabPosition)

        // Add a TabSelectedListener to handle tab changes dynamically
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                updateMenuBarVisibility(tab?.position ?: 0)
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                // Optional: handle if you need actions when a tab is unselected
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                // Optional: handle if you need actions when a tab is reselected
            }
        })

        // Setup click listener for accountDel button
        binding.accountDel.setOnClickListener {
            // Inflate the Bottom Sheet Dialog
            val bottomSheetBinding = AccountBottomSheetBinding.inflate(LayoutInflater.from(requireContext()))
            val bottomSheet = BottomSheetDialog(requireActivity())
            bottomSheet.setContentView(bottomSheetBinding.root)
            bottomSheet.show()
        }
    }

    private fun updateMenuBarVisibility(selectedPosition: Int) {
        when (selectedPosition) {
            2 -> binding.menuBar.visibility = View.GONE  // Tab at position 2 (third tab)
            else -> binding.menuBar.visibility = View.VISIBLE  // All other tabs
        }
    }
}

