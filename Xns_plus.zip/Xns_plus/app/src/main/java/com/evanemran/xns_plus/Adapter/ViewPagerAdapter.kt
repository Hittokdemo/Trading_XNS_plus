package com.evanemran.xns_plus.Adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.evanemran.xns_plus.Fragment.Performance.BenefitsFragment
import com.evanemran.xns_plus.Fragment.Performance.SummaryFragment

class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

    // Return the total number of tabs (fragments)
    override fun getItemCount(): Int {
        return 2 // For example, you have 3 tabs
    }

    // Return the fragment based on the position (each tab has its own fragment)
    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> SummaryFragment()  // The fragment for the first tab
            1 -> BenefitsFragment() // The fragment for the second tab
            else -> Fragment() // Default case
        }
    }
}