package com.evanemran.xns_plus.Activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.evanemran.xns_plus.databinding.ActivitySplashBinding

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)

        Handler().postDelayed({
            if (sharedPreferences.getBoolean("SignIn", false)) {
                startActivity(Intent(this, ConfirmPassordActivity::class.java))
            } else {
                startActivity(Intent(this, RegisterSignInActivity::class.java))
            }
            finish()
        }, 2000)

    }
}