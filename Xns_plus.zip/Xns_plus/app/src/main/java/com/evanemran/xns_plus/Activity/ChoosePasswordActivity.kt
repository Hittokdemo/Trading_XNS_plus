package com.evanemran.xns_plus.Activity

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.evanemran.xns_plus.MVVM.UserViewModel
import com.evanemran.xns_plus.Model.RegistrationModel
import com.evanemran.xns_plus.ProgressDialog.showProgressDialog
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.ActivityChoosePasswordBinding

class ChoosePasswordActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChoosePasswordBinding
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var NumberCode: String
    private lateinit var userEmail: String
    private var userPassword: String = ""
    private lateinit var progressDialog: ProgressDialog
    private lateinit var userViewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChoosePasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userViewModel = ViewModelProvider(this)[UserViewModel::class.java]
        sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)

        NumberCode = intent.getStringExtra("NumberCode").orEmpty()
        userEmail = intent.getStringExtra("userEmail").orEmpty()

        binding.continueBtn.setOnClickListener {
            userPassword = binding.passwordEdit.text.toString().trim()
            if (isValidPassword(userPassword)) {
                progressDialog = showProgressDialog(this, "Please wait...")
                val registrationModel = RegistrationModel(
                    email = userEmail,
                    mobile = "1234567890",
                    password = userPassword,
                    pass_code = "123456"
                )
                userViewModel.fetchRegistration(registrationModel)
            } else {
                Toast.makeText(this, "Password does not meet the requirements", Toast.LENGTH_SHORT).show()
            }
        }

        binding.showHide.setOnClickListener {
            if (binding.passwordEdit.inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                binding.passwordEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                binding.showHide.setImageResource(R.drawable.eye_icon)
            } else {
                binding.passwordEdit.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                binding.showHide.setImageResource(R.drawable.hide_icon)
            }
            binding.passwordEdit.setSelection(binding.passwordEdit.text.length)
        }

        binding.passwordEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                validatePassword(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        userViewModel.userResponse.observe(this, Observer { response ->
            progressDialog.dismiss()
            if (response?.status == "success") {
                startActivity(Intent(this, PasswordSecurelyActivity::class.java))
                Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, response?.message ?: "Registration failed", Toast.LENGTH_SHORT).show()
            }
        })

        userViewModel.error.observe(this, Observer { errorMessage ->
            progressDialog.dismiss()
            errorMessage?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun isValidPassword(password: String): Boolean {
        val passwordRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#\$%^&+=!])(?=\\S+\$).{8,}\$"
        return password.matches(passwordRegex.toRegex())
    }

    @SuppressLint("ResourceAsColor")
    private fun validatePassword(password: String) {
        val gray = ContextCompat.getColor(this, R.color.grey)
        binding.lowercaseUppercasePass.setTextColor(gray)
        binding.lowercaseUppercasePassView.setImageResource(R.drawable.bot_gray)
        binding.charactersPass.setTextColor(gray)
        binding.charactersPassView.setImageResource(R.drawable.bot_gray)
        binding.numberPass.setTextColor(gray)
        binding.numberPassView.setImageResource(R.drawable.bot_gray)

        val greenColor = ContextCompat.getColor(this, R.color.green)
        if (password.any { it.isLowerCase() } || password.any { it.isUpperCase() }) {
            binding.lowercaseUppercasePass.setTextColor(greenColor)
            binding.lowercaseUppercasePassView.setImageResource(R.drawable.dot_green)
        }
        if (password.any { it.isDigit() }) {
            binding.numberPass.setTextColor(greenColor)
            binding.numberPassView.setImageResource(R.drawable.dot_green)
        }
        if (password.length >= 8) {
            binding.charactersPass.setTextColor(greenColor)
            binding.charactersPassView.setImageResource(R.drawable.dot_green)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}
