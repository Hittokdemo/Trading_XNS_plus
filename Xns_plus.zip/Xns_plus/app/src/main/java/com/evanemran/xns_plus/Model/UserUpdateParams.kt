package com.evanemran.xns_plus.Model

import java.io.File

data class UserUpdateParams(
    val user_id: String?=null,
    val email: String?=null,
    val name: String?=null,
    val mobile: String?=null,
    val password: String?=null,
    val pass_code: String?=null,
    val image: File? = null
)

