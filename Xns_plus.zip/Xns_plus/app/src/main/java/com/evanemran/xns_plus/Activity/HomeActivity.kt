package com.evanemran.xns_plus.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.evanemran.xns_plus.Fragment.AccountFragment
import com.evanemran.xns_plus.Fragment.MarketsFragment
import com.evanemran.xns_plus.Fragment.PerformanceFragment
import com.evanemran.xns_plus.Fragment.ProfileFragment
import com.evanemran.xns_plus.Fragment.TradeFragment
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity(){
    lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)


        loadFragment(AccountFragment())
        binding.bottomNavigationView.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.AccountMenu -> {
                    loadFragment(AccountFragment())
                    true
                }
                R.id.tradeMenu -> {
                    loadFragment(TradeFragment())
                    true
                }
                R.id.marketMenu -> {
                    loadFragment(MarketsFragment())
                    true
                }
                R.id.performanceMenu -> {
                    loadFragment(PerformanceFragment())
                    true
                }
                R.id.profileMenu -> {
                    loadFragment(ProfileFragment())
                    true
                }

                else -> {
                    loadFragment(Fragment())
                    return@setOnItemSelectedListener true
                }
            }
        }


    }

    private  fun loadFragment(fragment: Fragment){
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.flFragment,fragment)
        transaction.commit()
    }
}