package com.evanemran.xns_plus.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evanemran.xns_plus.Adapter.ViewPagerAdapter
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.AccountBottomSheetBinding
import com.evanemran.xns_plus.databinding.FragmentAccountBinding
import com.evanemran.xns_plus.databinding.FragmentPerfomanceBinding
import com.evanemran.xns_plus.databinding.PeriodBottomSheetBinding
import com.evanemran.xns_plus.databinding.RealAccountsBottomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.tabs.TabLayoutMediator


class PerformanceFragment : Fragment() {
    private lateinit var binding: FragmentPerfomanceBinding
    private lateinit var adapter: ViewPagerAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View
    {
        // Inflate the layout using View Binding
        binding = FragmentPerfomanceBinding.inflate(inflater, container, false)
        // Setup the adapter for ViewPager2
        adapter = ViewPagerAdapter(requireActivity())
        binding.viewPagerId.adapter = adapter
        // Link the TabLayout and ViewPager2
        TabLayoutMediator(binding.tabBarLayout, binding.viewPagerId) { tab, position ->
            when (position) {
                0 -> tab.text = "Summary"
                1 -> tab.text = "Xns plus benefits"
            }
        }.attach()


        return binding.root
    }


}