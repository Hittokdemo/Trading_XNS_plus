package com.evanemran.xns_plus.Interface

import com.evanemran.xns_plus.Model.GetProfileModel
import com.evanemran.xns_plus.Model.UserResponse
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface GetProfileApiService {
    @FormUrlEncoded
    @POST("get_user")
    suspend fun getUserProfile(
        @Field("user_id") user_id:String
    ): Response<GetProfileModel>
}