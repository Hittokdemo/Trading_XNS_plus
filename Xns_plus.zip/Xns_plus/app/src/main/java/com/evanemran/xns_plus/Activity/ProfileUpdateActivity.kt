package com.evanemran.xns_plus.Activity

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.evanemran.xns_plus.MVVM.UserViewModel
import com.evanemran.xns_plus.Model.UserUpdateParams
import com.evanemran.xns_plus.ProgressDialog.showProgressDialog
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.ActivityProfileUpdateBinding
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class ProfileUpdateActivity : AppCompatActivity() {
    lateinit var binding: ActivityProfileUpdateBinding
    private val PICK_IMAGE_REQUEST = 1001
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var progressDialog: ProgressDialog
    private lateinit var userViewModel: UserViewModel
    private var profileImageFile: File ?=null
    private var userId = ""
    private lateinit var emailID:String
    private lateinit var passwordEmailid:String
    private lateinit var pss_Code:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileUpdateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userViewModel = ViewModelProvider(this)[UserViewModel::class.java]
        sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)
        userId = sharedPreferences.getString("userID","").toString()


        fetchUserProfile()

        userViewModel.getProfile.observe(this, Observer { response ->
            progressDialog.dismiss()
            if (response!=null){
                emailID = response.email.toString()
                passwordEmailid  = response.password.toString()
                pss_Code = response.pass_code.toString()

                val profileImage = "http://45.79.127.105/xnsplus/uploads/profile/"+response.image

                Glide.with(this).load(profileImage).placeholder(R.drawable.ic_launcher_background).into(binding.profileImg)
            }

        })
        userViewModel.userResponse.observe(this, Observer { response ->
            progressDialog.dismiss()
            if (response!=null){
                if (response.status == "success"){
                    startActivity(Intent(this,HomeActivity::class.java))
                    finish()
                    Toast.makeText(this,"message: "+ response.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this,"message: "+ response.message, Toast.LENGTH_SHORT).show()
                }

            }

        })
        userViewModel.error.observe(this, Observer { errorMessage ->
            progressDialog.dismiss()
            errorMessage?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            }
        })

        binding.profileImg.setOnClickListener {
            openGallery()
        }

        binding.saveBtn.setOnClickListener {
            userProfileUpdate()
        }
        binding.backBtn.setOnClickListener {
            startActivity(Intent(this,HomeActivity::class.java))
            finish()
        }
    }

    @Deprecated("This method has been deprecated in favor of using the\n   " +
            "   {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n    " +
            "  The OnBackPressedDispatcher controls how back button events are dispatched\n    " +
            "  to one or more {@link OnBackPressedCallback} objects.")
    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this,HomeActivity::class.java))
        finish()
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    private fun fetchUserProfile(){
        try {
            progressDialog = showProgressDialog(this, "Please wait...")
            userViewModel.getProfileUser(userId)
        }catch (e:Exception){
            progressDialog.dismiss()
        }
    }

    @Deprecated("This method has been deprecated in favor of using the Activity Result API...")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val imageUri = data.data

            // Convert imageUri to Bitmap
            imageUri?.let { uri ->
                try {
                    val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                    // Convert Bitmap to File
                    val imageFile = bitmapToFile(bitmap, "profile_image.png")
                    profileImageFile = imageFile
                    Glide.with(this).load(imageFile).placeholder(R.drawable.ic_launcher_background).into(binding.profileImg)

                } catch (e: IOException) {
                    e.printStackTrace()
                    progressDialog.dismiss()
                }
            }
        } else {
            // Handle case where no image was selected or the result was not OK
        }
    }


    private fun userProfileUpdate() {
        try {
            progressDialog = showProgressDialog(this, "Please wait...")
            val updateUser = UserUpdateParams(
                user_id = userId,
                name = binding.userName.text.toString().trim(),
                mobile = binding.userNumber.text.toString(),
                email = emailID,
                pass_code = pss_Code,
                password = passwordEmailid,
               image =  profileImageFile
            )
            userViewModel.userProfileUpdate(updateUser)
        } catch (e: Exception) {
            progressDialog.dismiss()
            Log.e("ProfileActivity", e.message.toString())
        }

    }

    private fun bitmapToFile(bitmap: Bitmap, fileName: String): File {
        // Create a file in the cache directory or any other desired directory
        val file = File(cacheDir, fileName)
        FileOutputStream(file).use { outputStream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        }
        return file
    }

}