package com.evanemran.xns_plus.Activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.evanemran.xns_plus.databinding.ActivityPasswordSecurelyBinding
import com.ozcanalasalvar.otp_view.view.OtpView

class PasswordSecurelyActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPasswordSecurelyBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPasswordSecurelyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener {
            finish()
        }

        binding.confirmPasswordInput.apply {
            setAutoFocusEnabled(false)
            setErrorEnabled(false)
            setTextChangeListener(object : OtpView.ChangeListener {
                override fun onTextChange(value: String, completed: Boolean) {
                    if (value.length == 6) {
                       val sharedPreferences = getSharedPreferences("ActivityCheck", MODE_PRIVATE)
                        val edits = sharedPreferences.edit()
                        edits.putString("confirmPassword",value)
                        edits.apply()
                        val intent = Intent(this@PasswordSecurelyActivity,ConfirmPassordActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }
            })
        }


    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }


}