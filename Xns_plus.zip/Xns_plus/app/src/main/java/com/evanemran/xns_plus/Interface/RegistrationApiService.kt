package com.evanemran.xns_plus.Interface

import com.evanemran.xns_plus.Model.UserResponse
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface RegistrationApiService {
    @FormUrlEncoded
    @POST("registration")
    suspend fun createUser(
        @Field("email") email:String,
        @Field("mobile") mobile: String,
        @Field("password") password: String,
        @Field("pass_code") pass_code: String
    ): Response<UserResponse>
}