package com.evanemran.xns_plus.Model

data class UserResponse(val status: String,
                        var message: String)
