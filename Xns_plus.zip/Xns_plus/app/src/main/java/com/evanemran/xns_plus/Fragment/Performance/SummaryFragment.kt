package com.evanemran.xns_plus.Fragment.Performance

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evanemran.xns_plus.R
import com.evanemran.xns_plus.databinding.AccountBottomSheetBinding
import com.evanemran.xns_plus.databinding.FragmentPerfomanceBinding
import com.evanemran.xns_plus.databinding.FragmentSummaryBinding
import com.evanemran.xns_plus.databinding.PeriodBottomSheetBinding
import com.evanemran.xns_plus.databinding.RealAccountsBottomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialog


class SummaryFragment : Fragment() {
    private lateinit var binding: FragmentSummaryBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View
    {
        // Inflate the layout for this fragment
        binding = FragmentSummaryBinding.inflate(inflater, container, false)
        binding.allReal.setOnClickListener {
            // Inflate the Bottom Sheet Dialog
            val bottomSheetBinding = RealAccountsBottomSheetBinding.inflate(LayoutInflater.from(requireContext()))
            val bottomSheet = BottomSheetDialog(requireActivity())
            bottomSheet.setContentView(bottomSheetBinding.root)
            bottomSheet.show()
        }
        binding.lastDay.setOnClickListener {
            // Inflate the Bottom Sheet Dialog
            val bottomSheetBinding = PeriodBottomSheetBinding.inflate(LayoutInflater.from(requireContext()))
            val bottomSheet = BottomSheetDialog(requireActivity())
            bottomSheet.setContentView(bottomSheetBinding.root)
            bottomSheet.show()
        }

        return binding.root
    }


}